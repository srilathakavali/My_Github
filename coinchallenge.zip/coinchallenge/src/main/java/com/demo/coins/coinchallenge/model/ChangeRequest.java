package com.demo.coins.coinchallenge.model;

public class ChangeRequest {
    private double amount;

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }
}

