package com.demo.coins.coinchallenge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoinchallengeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoinchallengeApplication.class, args);
	}

}
