package com.demo.coins.coinchallenge.model;

public class ChangeResponse {
    private int[] coinCounts;

    public int[] getCoinCounts() {
        return coinCounts;
    }

    public void setCoinCounts(int[] coinCounts) {
        this.coinCounts = coinCounts;
    }
}

