package com.demo.coins.coinchallenge.exception;

public class InsufficientCoinsException extends Exception {
    public InsufficientCoinsException(String message) {
        super(message);
    }
}
